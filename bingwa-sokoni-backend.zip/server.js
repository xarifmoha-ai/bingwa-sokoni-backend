const express = require("express");
const cors = require("cors");
const axios = require("axios");

const app = express();
const PORT = process.env.PORT || 10000;

app.use(cors());
app.use(express.json());

const BASE_URL = process.env.MPESA_BASE_URL || "https://sandbox.safaricom.co.ke";

function requireEnv(name) {
  if (!process.env[name]) throw new Error(`Missing environment variable: ${name}`);
  return process.env[name];
}

function normalizePhone(phone) {
  const p = String(phone || "").replace(/[\s-]/g, "");
  if (/^07\d{8}$/.test(p) || /^01\d{8}$/.test(p)) return "254" + p.slice(1);
  if (/^254[17]\d{8}$/.test(p)) return p;
  if (/^\+254[17]\d{8}$/.test(p)) return p.slice(1);
  throw new Error("Invalid Kenyan phone number.");
}

function timestamp() {
  const d = new Date();
  const pad = n => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth()+1)}${pad(d.getUTCDate())}${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}`;
}

async function accessToken() {
  const key = requireEnv("MPESA_CONSUMER_KEY");
  const secret = requireEnv("MPESA_CONSUMER_SECRET");
  const auth = Buffer.from(`${key}:${secret}`).toString("base64");

  const r = await axios.get(
    `${BASE_URL}/oauth/v1/generate?grant_type=client_credentials`,
    { headers: { Authorization: `Basic ${auth}` }, timeout: 15000 }
  );
  return r.data.access_token;
}

app.get("/", (req, res) => {
  res.json({ service: "Bingwa Sokoni M-PESA Backend", status: "online" });
});

app.get("/health", (req, res) => {
  res.json({ ok: true });
});

app.post("/api/stkpush", async (req, res) => {
  try {
    const shortcode = requireEnv("MPESA_SHORTCODE");
    const passkey = requireEnv("MPESA_PASSKEY");
    const callback = requireEnv("CALLBACK_URL");

    const phone = normalizePhone(req.body.phoneNumber);
    const amount = Number(req.body.amount);

    if (!Number.isInteger(amount) || amount < 1 || amount > 150000) {
      return res.status(400).json({
        success: false,
        message: "Amount must be a whole number from KES 1 to KES 150,000."
      });
    }

    const time = timestamp();
    const password = Buffer.from(`${shortcode}${passkey}${time}`).toString("base64");
    const token = await accessToken();

    const payload = {
      BusinessShortCode: shortcode,
      Password: password,
      Timestamp: time,
      TransactionType: "CustomerPayBillOnline",
      Amount: amount,
      PartyA: phone,
      PartyB: shortcode,
      PhoneNumber: phone,
      CallBackURL: callback,
      AccountReference: String(req.body.accountReference || "BINGWA").slice(0, 12),
      TransactionDesc: String(req.body.transactionDesc || "Bingwa Sokoni").slice(0, 13)
    };

    const r = await axios.post(
      `${BASE_URL}/mpesa/stkpush/v1/processrequest`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        timeout: 20000
      }
    );

    res.json({
      success: true,
      message: r.data.CustomerMessage || "STK Push sent.",
      checkoutRequestID: r.data.CheckoutRequestID || null,
      merchantRequestID: r.data.MerchantRequestID || null
    });
  } catch (e) {
    console.error(e.response?.data || e.message);
    res.status(500).json({
      success: false,
      message: e.response?.data?.errorMessage ||
               e.response?.data?.ResponseDescription ||
               e.message
    });
  }
});

app.post("/api/mpesa/callback", (req, res) => {
  console.log("M-PESA CALLBACK:", JSON.stringify(req.body, null, 2));
  res.json({ ResultCode: 0, ResultDesc: "Accepted" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Backend running on port ${PORT}`);
});
