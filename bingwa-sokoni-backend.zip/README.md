# Bingwa Sokoni Daraja Sandbox Backend

Deploy this Node.js service on Render.

Build command:
npm install

Start command:
npm start

Environment variables:
MPESA_CONSUMER_KEY
MPESA_CONSUMER_SECRET
MPESA_SHORTCODE
MPESA_PASSKEY
CALLBACK_URL
MPESA_BASE_URL=https://sandbox.safaricom.co.ke

Endpoints:
GET /health
POST /api/stkpush
POST /api/mpesa/callback

Never put Consumer Secret or Passkey in the Olitt HTML/JavaScript.
